"""
lyubishchev
~~~~~~~~~~~

Quantitative taxonomy methods of Alexander Alexandrovich Lyubishchev
(1890–1972), implemented as a Python library.

Lyubishchev was a Soviet entomologist and mathematician who developed
multivariate classification methods for biological taxonomy in 1943 —
twenty years before Sokal & Sneath published Principles of Numerical
Taxonomy (1963), and one year before Sokal & Sneath's methods were
memorialized in scipy.spatial.distance as sokalsneath and sokalmichener.

His formulations work on continuous measurements with full covariance
structure — mathematically more general than the binary-character
similarity coefficients that bear other researchers' names.

Primary source
--------------
Lyubishchev, A.A. (1943). Programma obshchey sistematiki
[Program of General Systematics]. Manuscript, 22 November 1943.
Digitized by ZIN RAS Coleoptera Laboratory.
http://www.zin.ru/animalia/coleoptera/rus/lyubis05.htm

Western publication
-------------------
Lubischew, A.A. (1962). On the use of discriminant functions
in taxonomy. Biometrics, 18(4), 455-477.

Basic usage
-----------
    >>> import numpy as np
    >>> from lyubishchev import divergence_coefficient, scatter_ellipse, classify
    >>>
    >>> rng = np.random.default_rng(42)
    >>> oleracea = rng.multivariate_normal([3.2, 1.5], [[0.1, 0.05], [0.05, 0.1]], 20)
    >>> carduorum = rng.multivariate_normal([3.8, 1.9], [[0.1, 0.05], [0.05, 0.1]], 20)
    >>>
    >>> X = np.vstack([oleracea, carduorum])
    >>> y = ['oleracea'] * 20 + ['carduorum'] * 20
    >>>
    >>> D = divergence_coefficient(oleracea, carduorum)
    >>> ellipses = scatter_ellipse(X, y)
    >>> result = classify(np.array([3.75, 1.85]), ellipses)
    >>> max(result, key=lambda k: result[k]['posterior'])
    'carduorum'
"""

from .core import (
    divergence_coefficient,
    scatter_ellipse,
    transgression,
    classify,
)

__all__ = [
    'divergence_coefficient',
    'scatter_ellipse',
    'transgression',
    'classify',
]

__version__ = '0.1.0'
__author__ = 'Akzhan Berdeyev'
__email__ = 'akzhan.berdeyev@gmail.com'
